const mongoose = require('mongoose');
mongoose.connect('mongodb://localhost/GKUKIB');

module.exports = mongoose;